package com.demo.pa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
