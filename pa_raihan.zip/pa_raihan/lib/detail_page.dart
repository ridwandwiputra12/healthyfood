// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DetailPage extends StatelessWidget {
  DetailPage(
      {Key? key,
      required this.id,
      required this.image,
      required this.nama,
      required this.keterangan,
      required this.bahan,
      required this.jenis,
      required this.harga})
      : super(key: key);

  final String image, nama, keterangan, bahan, jenis, harga, id;

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var panjang = MediaQuery.of(context).size.height;
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference order = firestore.collection("order");
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(
              top: 20,
            ),
            height: 100,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(
                    left: 10,
                    right: 10,
                  ),
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage("assets/gambar.png")),
                      borderRadius: BorderRadius.circular(35)),
                ),
                Text(
                  nama,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Container(
            height: 300,
            child: Row(
              children: [
                Container(
                  margin: EdgeInsets.only(
                    left: lebar / 4,
                  ),
                  width: (lebar / 2) - 10,
                  decoration: BoxDecoration(
                      image: DecorationImage(image: NetworkImage(image))),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(
              top: 20,
              left: 20,
            ),
            child: Text(
              "KETERANGAN",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 5, right: 20, left: 20),
            child: Text(
              keterangan,
              style: TextStyle(
                fontSize: 15,
              ),
              textAlign: TextAlign.justify,
            ),
          ),
          Container(
            margin: EdgeInsets.only(
              top: 50,
              left: 20,
            ),
            child: Text(
              "Jenis Makanan :",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10, left: 20),
            child: Text(
              jenis,
              style: TextStyle(
                fontSize: 15,
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 30, left: 20),
            child: Text(
              "Bahan :",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10, left: 20),
            child: Text(
              bahan,
              style: TextStyle(
                fontSize: 15,
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 30, left: 20),
            child: Text(
              "Harga :",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10, left: 20),
            child: Text(
              harga,
              style: TextStyle(
                fontSize: 15,
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          GestureDetector(
            onTap: () {
              order.add({"gambar": image, "nama": nama, "status": "dipesan"});

              Get.snackbar(
                "",
                "",
                backgroundColor: Colors.blueAccent,
                icon: Icon(
                  Icons.close,
                  color: Colors.white,
                ),
                titleText: Text(
                  "Order Success",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w600),
                ),
                messageText: Text(
                  'Silahkan Tunggu pesanan anda dikirim',
                  style: TextStyle(color: Colors.white),
                ),
              );
            },
            child: Container(
              width: 100,
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.brown,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                "Tambahkan Keranjang",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }
}
