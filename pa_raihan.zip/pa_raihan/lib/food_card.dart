import 'package:flutter/material.dart';
import 'package:pa_raihan/detail_page.dart';
import 'package:get/get.dart';

class FoodCard extends StatelessWidget {
  const FoodCard(
      {Key? key,
      required this.image,
      required this.nama,
      required this.keterangan,
      required this.jenis,
      required this.bahan,
      required this.harga,
      required this.id})
      : super(key: key);

  final String image, nama, keterangan, jenis, bahan, harga, id;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        right: 7,
        left: 10,
      ),
      child: ElevatedButton(
        child: Container(
          width: (MediaQuery.of(context).size.width / 2) - 50,
          height: 250,
          decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(image),
              ),
              borderRadius: BorderRadius.circular(30)),
        ),
        onPressed: () {
          print("tes");
          Get.to(DetailPage(
              id: id,
              image: image,
              nama: nama,
              keterangan: keterangan,
              bahan: bahan,
              jenis: jenis,
              harga: harga));
        },
        style: ElevatedButton.styleFrom(
          primary: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        ),
      ),
    );
  }
}
