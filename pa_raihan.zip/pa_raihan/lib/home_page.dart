import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pa_raihan/food_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var panjang = MediaQuery.of(context).size.height;

    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference food = firestore.collection("food");

    return Container(
      child: ListView(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: StreamBuilder<QuerySnapshot>(
                stream: food.snapshots(),
                builder: (context, snapshot) {
                  return snapshot.hasData
                      ? Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              children: snapshot.data!.docs
                                  .map((e) => FoodCard(
                                      id: e.id,
                                      image: e.get("gambar"),
                                      nama: e.get("nama"),
                                      keterangan: e.get("keterangan"),
                                      jenis: e.get("jenis"),
                                      bahan: e.get("bahan"),
                                      harga: e.get("harga")))
                                  .toList()),
                        )
                      : Container();
                }),
          ),
        ],
      ),
    );
  }
}
