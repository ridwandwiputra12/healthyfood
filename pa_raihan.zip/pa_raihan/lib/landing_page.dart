// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pa_raihan/main_page.dart';

class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 167, 83, 134),
      body: Container(
        child: Stack(
          children: [
            Positioned(
              left: -65.0,
              bottom: 0.0,
              child: Container(
                width: 300.0,
                height: 300,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/gambar2.png'))),
              ),
            ),
            Positioned(
              right: -60.0,
              bottom: -10.0,
              child: Container(
                width: 250.0,
                height: 500,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/gambar.png'))),
              ),
            ),
            Positioned(
              top: 0.0,
              left: 0.0,
              width: MediaQuery.of(context).size.width,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 24.0),
                height: MediaQuery.of(context).size.height,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 150.0,
                    ),
                    Text(
                      "Healthy Food\nPremium Natural\nIngredients",
                      style: TextStyle(
                        fontSize: 34.0,
                        height: 1.3,
                        color: Color.fromARGB(255, 248, 181, 99),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(
                      height: 7.0,
                    ),
                    Text(
                      "When Healthy Met Tasty",
                      style: TextStyle(
                        fontSize: 18.0,
                        height: 1.8,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                        onPressed: () {
                          Get.to(MainPage());
                          // Get.to(MyMainPage());
                        },
                        child: const Text("Order"),
                        style: ElevatedButton.styleFrom(primary: Colors.lime)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
