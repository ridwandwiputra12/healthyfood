// ignore_for_file: prefer_const_declarations, prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pa_raihan/controllers/main_page_controller.dart';
import 'package:pa_raihan/home_page.dart';
import 'package:pa_raihan/order_page.dart';
// import 'package:pa_syawy/controllers/main_page_controller.dart';
// import 'package:pa_syawy/home_page.dart';
// import 'package:pa_syawy/profile_page.dart';
// import 'package:pa_syawy/search_page.dart';

class MainPage extends StatelessWidget {
  MainPage({Key? key}) : super(key: key);
  final List<BottomNavigationBarItem> _myItem = const [
    BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: "Home",
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: "Pemesanan",
    ),
  ];

  final List<Widget> _myPages = [HomePage(), OrderPage()];
  final MainPageController mainPageController = Get.put(MainPageController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MainPageController>(
      builder: (controller) {
        return Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: const Color(0xFFF0E2E2),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              backgroundColor: const Color(0xffAE7E73),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Let's Get Healthy Food",
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            body: _myPages.elementAt(controller.tabIndex),
            bottomNavigationBar: BottomNavigationBar(
              backgroundColor: Color(0xffAE7E73),
              selectedItemColor: Color(0xffF0E2E2),
              unselectedItemColor: Colors.black,
              currentIndex: controller.tabIndex,
              items: _myItem,
              onTap: controller.changeTabIndex,
            ),
          ),
        );
      },
    );
  }
}
