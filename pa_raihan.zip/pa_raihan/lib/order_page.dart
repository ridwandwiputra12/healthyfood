// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:pa_raihan/list_pemesanan_card.dart';

class OrderPage extends StatelessWidget {
  const OrderPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    FirebaseFirestore firestore = FirebaseFirestore.instance;
    CollectionReference order = firestore.collection("order");

    Future<dynamic> CustomAlert(BuildContext context, String id) {
      return showDialog(
        context: context,
        builder: (context) {
          return StreamBuilder<DocumentSnapshot>(
              stream: order.doc(id).snapshots(),
              builder: (context, snapshot) {
                return (snapshot.hasData)
                    ? AlertDialog(
                        backgroundColor: const Color.fromRGBO(130, 130, 168, 1),
                        actions: [
                          Column(
                            children: [
                              Text("Pesanan Diterima?",
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 20)),
                              const SizedBox(
                                height: 30,
                              ),
                              Image.asset(
                                "assets/success.png",
                                width: 200,
                                height: 200,
                              ),
                              const SizedBox(
                                height: 30,
                              ),
                              Container(
                                padding: EdgeInsets.all(12),
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: InkWell(
                                  onTap: () {
                                    order
                                        .doc(id)
                                        .update({'status': 'diterima'});
                                    Navigator.of(context).pop();
                                  },
                                  child: const Text(
                                    "Selesai",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: Color.fromRGBO(89, 87, 138, 1),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )
                    : Text('Loading....');
              });
        },
      );
    }

    return ListView(
      children: [
        StreamBuilder<QuerySnapshot>(
            stream: order.snapshots(),
            builder: (context, snapshot) {
              return snapshot.hasData
                  ? Column(
                      children: snapshot.data!.docs
                          .map((e) => ListPemesananCard(
                                image: e.get("gambar"),
                                name: e.get("nama"),
                                type: e.get("status"),
                                onUpdate: () {
                                  CustomAlert(context, e.id);
                                },
                                onDelete: () {
                                  order.doc(e.id).delete();
                                },
                              ))
                          .toList())
                  : Container();
            })
      ],
    );
  }
}
