// ignore_for_file: prefer_const_constructors

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pa_raihan/landing_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    splashScreenStart();
  }

  splashScreenStart() {
    var duration = Duration(seconds: 4);
    return Timer(duration, () {
      Get.to(LandingPage());
    });
  }

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Center(
        child: Container(
          width: (lebar / 2) - 10,
          height: 300,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/logo_aplikasi.png'))),
        ),
      ),
      backgroundColor: Color.fromRGBO(240, 128, 128, 100),
    );
  }
}
